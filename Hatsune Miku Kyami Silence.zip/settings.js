const fs = require('fs');
const chalk = require('chalk');

/*
	* Create By Naze & Kyami 
	* Subs : https://youtube.com/@slnckyami
	* Follow https://github.com/nazedev
	* Whatsapp : https://chat.whatsapp.com/Fg7lZNth6WPCkTmxfNzvdh
*/

//~~~~~~~~~~~~< GLOBAL SETTINGS >~~~~~~~~~~~~\\

global.owner = ['6285167249152'] //['6285174340858','6281356484612','6282113821188']
global.packname = '𝘉𝘰𝘵 𝘞𝘩𝘢𝘵𝘴𝘢𝘱𝘱'
global.author = '𝘏𝘢𝘵𝘴𝘶𝘯𝘦 𝘔𝘪𝘬𝘶'
global.botname = '𝘏𝘢𝘵𝘴𝘶𝘯𝘦 𝘔𝘪𝘬𝘶'
global.listprefix = ['+','!','.']
global.listv = ['•','●','■','✿','▲','➩','➢','➣','➤','✦','✧','△','❀','○','□','♤','♡','◇','♧','々','〆']
global.tempatDB = 'database.json'
global.pairing_code = true
global.number_bot = '6283137133540' // 𝘔𝘢𝘴𝘶𝘬𝘪𝘯 𝘕𝘰𝘮𝘰𝘳 𝘠𝘨 𝘔𝘢𝘶 𝘑𝘢𝘥𝘪 𝘉𝘰𝘵 𝘋𝘪 𝘚𝘪𝘯𝘪 𝘉𝘶𝘢𝘵 𝘋𝘢𝘱𝘦𝘵𝘪𝘯 𝘒𝘰𝘥𝘦 𝘗𝘢𝘪𝘳𝘪𝘯𝘨
global.fake = {
	anonim: 'https://img86.pixhost.to/images/594/564772699_asytzy.jpg',
	thumbnailUrl: 'https://img86.pixhost.to/images/594/564772699_asytzy.jpg',
	thumbnail: fs.readFileSync('./src/media/kyami.png'),
	docs: fs.readFileSync('./src/media/fake.pdf'),
	listfakedocs: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/pdf'],
}

global.my = {
	yt: 'https://youtube.com/@slnckyami',
	gh: 'https://lynk.id/kyamihere',
	gc: 'https://chat.whatsapp.com/Fg7lZNth6WPCkTmxfNzvdh',
	ch: '120363366790950043@newsletter',
}

global.limit = {
	free: 20,
	premium: 999,
	vip: 9999
}

global.uang = {
	free: 10000,
	premium: 1000000,
	vip: 10000000
}

global.mess = {
	key0: 'Apikey mu telah habis silahkan kunjungi\nhttps://my.hitori.pw',
	owner: 'Fitur Khusus Owner!',
	admin: 'Fitur Khusus Admin!',
	botAdmin: 'Bot Bukan Admin!',
	group: 'Gunakan Di Group!',
	private: 'Gunakan Di Privat Chat!',
	limit: 'Limit Anda Telah Habis!',
	prem: 'Khusus User Premium!',
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

global.APIs = {
	hitori: 'https://my.hitori.pw/api',
}
global.APIKeys = {
	'https://my.hitori.pw/api': 'htrkey-awokawok',
}

//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});
